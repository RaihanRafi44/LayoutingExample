//Raihan Rafi Rizqullah

data class Food( //Food variable
    var foodNumber: Int,
    var foodName : String,
    var foodPrice : Int
)

