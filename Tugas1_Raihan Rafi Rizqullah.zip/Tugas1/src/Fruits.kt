//Raihan Rafi Rizqullah

data class Fruits(
    var fruitsName: String,
    var fruitsPrice: Int
)